Domácí služby pro lidi - jednoduchý one-page web (dark theme)

Součásti:
- index.html
- styles.css
- assets/logo.svg

Jak použít:
1) Rozbal ZIP a nahraj obsah do svého GitHub repozitáře (Upload files).
2) Otevři index.html lokálně nebo nastav GitHub Pages (pokud chceš veřejně publikovat).
3) Fotky a detailní ceník můžeš doplnit později do sekce /gallery a /pricing.

Úpravy:
- Změna kontaktních údajů: index.html -> sekce #contact
- Přidání fotek: vytvoř složku assets/images a nahraj tam
